## À faire

- Afficher un message lorsqu'aucun aperçu n'est affiché
- Améliorer le système de détection d'erreur et afficher un composant "alert" bootstrap
- Ajouter d'autres paramètres d'affichage de lieu
- Corriger le bouton individu qui ne remplit pas l'espace comme devrait le faire un élément `col-12`
- Ajouter un lecteur de fichier CSV pour définir une palette de couleurs personnalisée
- Ajouter un paramètre de modification de l'épaisseur des traits
- Le contraste automatique ne fonctionne pas encore sur les cases "mariage"
- Le nom du fichier téléchargé devrait indiquer le nom de l'individu dont il est question (ex. "Eventail généalogique de X")
- Ajouter un paramètre pour modifier la taille des marges
- Ajouter deux paramètres titre et sous-titre
- Ajouter un paramètre optionnel et désactivé par défaut qui afficherait un lien vers le site pour faire connaître le service
- Ajouter une 9ème et éventuellement 10ème génération avec une police de caractères plus petite
- Ajouter un paramètre pour afficher les métiers des quatre premières générations
