import './scripts/vendor/jquery'
import './scripts/vendor/bootstrap'
import 'bootstrap-select'

import './scripts/insee/main'

