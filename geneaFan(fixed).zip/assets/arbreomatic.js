// JavaScript
import './scripts/geneafan/main'

// Styles
import './scss/main.scss'

require.context('./other', true);
require.context('./images/icons', true);
