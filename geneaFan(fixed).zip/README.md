- npm install
- npm run dev
- UI in English available at /en/index.html

![geneaFan](https://github.com/frankbracq/geneaFan/assets/35921662/25ef04f6-c02f-4957-b00d-21e560fcdbb0)

## Licence


